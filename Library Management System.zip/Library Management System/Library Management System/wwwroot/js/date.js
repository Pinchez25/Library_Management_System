﻿/*$(document).ready(function() {
    $("#DateOfPublication").datepicker({
        dateFormat:"dd-mm-yy",
        //minDate: -0,
        maxDate: "+0M +0D"

    });
});*/