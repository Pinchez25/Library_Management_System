﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Library_Management_System.Models
{
    public class Book
    {
       [Key]
       public int Id { get; set; }
       [Required]
       public string Title { get; set; }
       [Required]
       public string Author { get; set; }

       [Required(ErrorMessage ="Date of publication required")]
       [DisplayName("Publication Date")]
       [DataType(DataType.Date)]  
       public DateTime DateOfPublication { get; set; }

       [Required]
       public string Publisher { get; set; }
       [Required]
       public string ISBN { get; set; }
       [Required(ErrorMessage =  "Date of publication required")]
       [DataType(DataType.Date)]
       [DisplayName("Date of Release")]
       public DateTime ReleaseDate { get; set; }
       
       
           
       
        
    }
}