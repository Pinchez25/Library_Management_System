﻿using System;
using Microsoft.EntityFrameworkCore;
using Library_Management_System.Models;


namespace Library_Management_System.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options)
        {
            
        }
        public DbSet<Book> books { get; set; }
    }
    
}