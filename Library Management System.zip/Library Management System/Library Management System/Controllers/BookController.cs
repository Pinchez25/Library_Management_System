﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Library_Management_System.Data;
using Library_Management_System.Models;
namespace Library_Management_System.Controllers
{
    public class BookController : Controller
    {
        
        private readonly ApplicationDbContext _db;

        public BookController(ApplicationDbContext db)
        {
            _db = db;
        }
        // GET
        public IActionResult Index()
        {
            IEnumerable<Book> objList = _db.books;
                
            return View(objList);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Book bk)
        {
            if (!ModelState.IsValid) return View(bk);
            _db.books.Add(bk);
            _db.SaveChanges();
            return RedirectToAction("Index");

        }
        
        
        
    }
}